from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

origins = ["http://localhost:5173"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class MetaleInput(BaseModel):
    platyna: float
    pallad: float
    rod: float

CENY = {
    "platyna": 32.00,
    "pallad": 45.00,
    "rod": 250.00,
}

@app.post("/oblicz")
def oblicz_wartosc(data: MetaleInput):
    wartosc = (
        data.platyna * CENY["platyna"] +
        data.pallad * CENY["pallad"] +
        data.rod * CENY["rod"]
    )
    return {"wartosc": round(wartosc, 2)}
